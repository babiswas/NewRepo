package Middleware

import (
	"fmt"
	"nwapp/JWTUtil"

	"github.com/gin-gonic/gin"
)

func AuthMiddleWare(c *gin.Context) {
	tokenString, err := c.Cookie("token")

	if err != nil {
		fmt.Println("Token missing in cookie.")
		c.Abort()
		return
	}

	if JWTUtil.IsAuthenticated(tokenString) {
		c.Next()
	} else {
		c.Abort()
	}
}
