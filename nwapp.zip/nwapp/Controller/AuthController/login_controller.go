package AuthController

import (
	"log"
	"net/http"

	db "nwapp/DBUtil"
	"nwapp/JWTUtil"
	usermodel "nwapp/Model/User"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func LoginPage(c *gin.Context) {
	log.Println("Serving the user login page.")
	c.HTML(http.StatusOK, "loginform.tmpl.html", gin.H{})
}

func LoginSubmit(c *gin.Context) {
	log.Println("Processing user login data.")
	username := c.PostForm("username")
	password := c.PostForm("password")

	user := usermodel.User{}
	err := db.DB.Where("username = ?", username).First(&user).Error

	if err != nil {
		c.HTML(http.StatusBadRequest, "error400.tmpl.html", gin.H{
			"Message": "User not found.",
		})
	}

	if user.IsLoggedIn {
		c.Redirect(http.StatusFound, "/home")
	}

	log.Println("Verifying password:", password)
	err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password))

	if err == nil {
		log.Println("Password processed correctly.Redirecting the user.")
		user.IsLoggedIn = true
		role := usermodel.Role{}
		err = db.DB.Where("id=?", user.RoleID).First(&role).Error
		if err != nil {
			c.HTML(http.StatusInternalServerError, "error500.tmpl.html", gin.H{
				"Message": "Failed to create jwt token.",
			})
		}
		token, err := JWTUtil.CreateToken(user.Username, role.Name)
		if err != nil {
			c.HTML(http.StatusInternalServerError, "error500.tmpl.html", gin.H{
				"Message": "Failed to create jwt token.",
			})
		}
		c.SetCookie("token", token, 3600, "/", "localhost", true, false)
		c.Redirect(http.StatusFound, "/home")
	} else {
		c.HTML(http.StatusOK, "errorpass.tmpl.html", gin.H{
			"Messsage": "Incorrect Password.",
		})
	}
}
