package Controller

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

func HomePage(c *gin.Context) {
	log.Println("Serving the home page.")
	c.HTML(http.StatusOK, "message.tmpl.html", gin.H{
		"Message": "Hello User",
		"Content": "This is new content",
	})
}
