package RegistrationController

import (
	"log"
	"net/http"
	"nwapp/Model/User"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"

	db "nwapp/DBUtil"
)

func RegisterUser(c *gin.Context) {
	log.Println("Executing user registration controller.")

	username := c.PostForm("username")
	password := c.PostForm("password")
	email := c.PostForm("email")

	processed_password, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	if err != nil {
		log.Println("Error occured while calculating hash for the password.")
		c.Status(http.StatusInternalServerError)
	}

	log.Printf("Creating user having username:%s ,email:%s ,password:%s", username, email, processed_password)
	user_obj := User.User{
		Username:   username,
		Password:   string(processed_password),
		Email:      email,
		IsLoggedIn: false,
		RoleID:     2,
	}
	db.DB.Create(&user_obj)
	c.Redirect(http.StatusFound, "/auth/login")
}

func RegistrationPage(c *gin.Context) {
	log.Println("Displaying page to register user.")
	c.HTML(http.StatusOK, "user_form.tmpl.html", gin.H{})
}
