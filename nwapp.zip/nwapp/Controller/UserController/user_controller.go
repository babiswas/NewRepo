package UserController

import (
	"log"
	"net/http"

	db "nwapp/DBUtil"
	usermodel "nwapp/Model/User"

	"github.com/gin-gonic/gin"
)

func AllUser(c *gin.Context) {
	log.Println("Executing all user controller.")
	var users []usermodel.User
	db.DB.Find(&users)
	c.HTML(http.StatusOK, "users.tmpl.html", gin.H{
		"users":    users,
		"allusers": "User List",
	})
}

func UserByID(c *gin.Context) {
	log.Println("Executing user by username controller.")

	username := c.Query("username")
	if username == "" {
		c.HTML(http.StatusOK, "user.tmpl.html", gin.H{})
	} else {
		log.Printf("Username obtained:%s", username)
		user := usermodel.User{}
		db.DB.Where("username = ?", username).First(&user)
		c.HTML(http.StatusOK, "user.tmpl.html", gin.H{
			"user": user,
		})
	}
}
