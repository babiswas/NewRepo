package DBUtil

import (
	"log"
	"nwapp/Model/User"
)

func CreateRole() {
	roles := []*User.Role{
		{Name: "Admin", ID: 1},
		{Name: "User", ID: 2},
	}

	log.Println("Verifying and creating desired roles in Roles table.")

	err := DB.Model(&User.Role{}).Where("name=?", "Admin").Error
	if err != nil {
		DB.Create(roles[0])
	}
	err = DB.Model(&User.Role{}).Where("name=?", "User").Error
	if err != nil {
		DB.Create(roles[1])
	}
}
