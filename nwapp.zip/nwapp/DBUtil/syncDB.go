package DBUtil

import "nwapp/Model/User"

func SyncDB() {
	DB.AutoMigrate(&User.User{})
	DB.AutoMigrate(&User.Role{})
}
