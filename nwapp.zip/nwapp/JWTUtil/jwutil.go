package JWTUtil

import (
	"log"
	"os"
	"time"

	"github.com/golang-jwt/jwt"
)

func CreateToken(username string, role string) (string, error) {
	log.Println("Executing create token function.", "Role:", role, "Username:", username)
	claims := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"sub": username,
		"iss": "nwapp",
		"aud": role,
		"exp": time.Now().Add(time.Hour).Unix(),
		"iat": time.Now().Unix(),
	})

	log.Println("Generate token string:")
	SECRET := os.Getenv("SECRET")

	tokenString, err := claims.SignedString([]byte(SECRET))

	if err != nil {
		log.Println("Error occured while creating token string:", err)
		return "", err
	}
	log.Println("Token string generated sucessfully:", tokenString)
	return tokenString, nil
}

func IsAuthenticated(tokenString string) bool {
	log.Println("Executing routine for verifying the token.")
	SECRET := os.Getenv("SECRET")
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		return []byte(SECRET), nil
	})
	if err != nil {
		return false
	}

	if token.Valid {
		return true
	} else {
		return false
	}
}

func IsAuthorized(tokenString string, role string) bool {
	log.Println("Executing routine for verifying the token.")
	SECRET := os.Getenv("SECRET")
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		return []byte(SECRET), nil
	})
	if err != nil {
		return false
	}

	claims, ok := token.Claims.(jwt.MapClaims)

	if ok && token.Valid {
		log.Println("Current role of the user is:", claims["aud"])
		return claims["aud"] == role
	}

	return false
}
