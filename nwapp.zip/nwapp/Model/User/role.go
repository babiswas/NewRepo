package User

type Role struct {
	ID   int
	Name string
}
