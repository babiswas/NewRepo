package User

import "gorm.io/gorm"

type User struct {
	gorm.Model
	Username   string
	Password   string
	Email      string
	IsLoggedIn bool
	RoleID     int
	Role       Role
}
