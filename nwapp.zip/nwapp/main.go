package main

import (
	"log"
	home_page "nwapp/Controller"
	auth_cntrl "nwapp/Controller/AuthController"
	reg_cntrl "nwapp/Controller/RegistrationController"
	user_cntrl "nwapp/Controller/UserController"
	dbutil "nwapp/DBUtil"
	mdlewre "nwapp/Middleware"

	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
)

func init() {
	log.Println("Loading the enviroment variable.")
	dbutil.LoadENVar()

	log.Println("Connecting to the database.")
	dbutil.ConnectDB()

	log.Println("Creating the tables.")
	dbutil.SyncDB()

	log.Println("Creating common data:")
	dbutil.CreateRole()
}

func main() {
	router := gin.Default()
	store := cookie.NewStore([]byte("secret-key"))
	router.Use(sessions.Sessions("mysession", store))

	router.LoadHTMLGlob("templates/**/*.html")

	router.GET("/home", mdlewre.AuthMiddleWare, home_page.HomePage)

	register := router.Group("/register")
	{
		register.GET("/", reg_cntrl.RegistrationPage)
		register.POST("/", reg_cntrl.RegisterUser)
	}

	auth := router.Group("/auth")
	{
		auth.GET("/login", auth_cntrl.LoginPage)
		auth.POST("/login", auth_cntrl.LoginSubmit)
	}

	user_mgmt := router.Group("/usermgmt")
	{
		user_mgmt.GET("/allUser", user_cntrl.AllUser)
		user_mgmt.GET("/user", user_cntrl.UserByID)
	}

	router.Run(":8080")
}
